﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GeneticAlgorithm1
{
    public class Population
    {
        public String code = "";
        public float fitness = 0;
    }
}
